% Plot transformation by a matrix
% Author: Nagabhushan S N
% Date: 30/10/2020

clc;
clearvars;
close all;


figure; hold on;
axis([-2, 2, -2, 2]);
axis square;

angle = 0:30:330;
rad_angle = angle * pi / 180;
vecs = [cos(rad_angle); sin(rad_angle)]';


[num_vecs, vec_dim] = size(vecs);
assert(vec_dim == 2);
for i=1:num_vecs
    quiver(0,0,vecs(i,1),vecs(i,2), 'k');
    if i <= 3
        pause;
    end
end

%% Rotating vector animation
pause; hold off;

angle = 0:1:360;
rad_angle = angle * pi / 180;
vecs = [cos(rad_angle); sin(rad_angle)]';
[num_vecs, vec_dim] = size(vecs);
assert(vec_dim == 2);
for i=1:num_vecs
    quiver(0,0,vecs(i,1),vecs(i,2), 'k');
    axis([-2, 2, -2, 2]);
    pause(0.01);
end
axis([-2, 2, -2, 2]);

%% Plot unit ball

pause(2);
angle = 0:0.1:360;
rad_angle = angle * pi / 180;
x = cos(rad_angle);
y = sin(rad_angle);
scatter(x,y, 'k.');
axis([-2, 2, -2, 2]);