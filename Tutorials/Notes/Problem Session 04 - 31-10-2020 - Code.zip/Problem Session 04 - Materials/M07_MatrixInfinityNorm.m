% Plot transformation by a matrix
% Author: Nagabhushan S N
% Date: 30/10/2020

clc;
clearvars;
close all;

axis_lt = 3;
% A = [2, 2; 5, -1];
A = [2, 0; 2, 1];


figure; hold on;
axis([-axis_lt, axis_lt, -axis_lt, axis_lt]);
axis square;

angle = 0:30:330;
rad_angle = angle * pi / 180;
vecs = [cos(rad_angle); sin(rad_angle)]';
vecs = vecs ./ max(abs(vecs), [], 2);    % Normalize with Infinity Norm
trans_vecs = (A * vecs')';


[num_vecs, vec_dim] = size(vecs);
assert(vec_dim == 2);
for i=1:num_vecs
    quiver(0,0,vecs(i,1),vecs(i,2), 'b');
    if i <= 3
        pause;
    end
    quiver(0,0,trans_vecs(i,1),trans_vecs(i,2), 'k');
    if i <= 3
        pause;
    end
end

%% Rotating vector animation
pause; hold off;

angle = 0:1:360;
rad_angle = angle * pi / 180;
vecs = [cos(rad_angle); sin(rad_angle)]';
vecs = vecs ./ max(abs(vecs), [], 2);    % Normalize with Infinity Norm
trans_vecs = (A * vecs')';

[num_vecs, vec_dim] = size(vecs);
assert(vec_dim == 2);
for i=1:num_vecs
    hold off;
    quiver(0,0,vecs(i,1),vecs(i,2), 'b');
    hold on;
    quiver(0,0,trans_vecs(i,1),trans_vecs(i,2), 'k');
    axis([-axis_lt, axis_lt, -axis_lt, axis_lt]);
    pause(0.01);
end
axis([-axis_lt, axis_lt, -axis_lt, axis_lt]); hold off;

%% Plot unit ball

pause(2);
angle = 0:0.1:360;
rad_angle = angle * pi / 180;
vecs = [cos(rad_angle); sin(rad_angle)]';
vecs = vecs ./ max(abs(vecs), [], 2);    % Normalize with Infinity Norm
trans_vecs = (A * vecs')';
x = vecs(:,1);
y = vecs(:,2);
tx = trans_vecs(:,1);
ty = trans_vecs(:,2);
scatter(x,y, 'b.');
hold on; scatter(tx,ty, 'k.');
axis([-axis_lt, axis_lt, -axis_lt, axis_lt]);

%% Plot vector that gives matrix norm 

pause(2);
trans_norm = max(abs(trans_vecs), [], 2);
[max_val, max_pos] = max(trans_norm);
max_vec = vecs(max_pos, :);
max_trans_vec = trans_vecs(max_pos, :);
quiver(0,0,max_vec(1),max_vec(2), 'b');
quiver(0,0,max_trans_vec(1),max_trans_vec(2), 'k');