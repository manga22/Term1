% Plot transformation by a matrix
% Author: Nagabhushan S N
% Date: 30/10/2020

clc;
clearvars;
close all;

A = [2, 2; 5, -1];

% % Constrcut a matrix with specified eigen vectors
% % https://math.stackexchange.com/a/1119690/516816
% S = [1, 2; 0, 1]';
% M = [2, 0; 0, 1];
% A = S*M*S^-1;

% What matrices give same scaling and rotation for all vectors?


figure; hold on;
axis([0, 6, 0, 6]);
axis square;

x1 = [1; 0.4];
y1 = A*x1;
quiver(0, 0, x1(1), x1(2), 'r');
pause; quiver(0, 0, y1(1), y1(2), 'r--');

x2 = [1; 2];
y2 = A*x2;
pause; quiver(0, 0, x2(1), x2(2), 'b');
pause; quiver(0, 0, y2(1), y2(2), 'b--');

x3 = [1; 1];    % Eigen vector for first matrix.
y3 = A*x3;
pause; quiver(0, 0, x3(1), x3(2), 'm');
pause; quiver(0, 0, y3(1), y3(2), 'm--');